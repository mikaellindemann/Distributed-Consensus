﻿namespace Event.Models.UriClasses
{
    public class ConditionUri : UriRepresentationBase
    {
    }
}