﻿namespace Event.Models.UriClasses
{
    public class ExclusionUri : UriRepresentationBase
    {
    }
}