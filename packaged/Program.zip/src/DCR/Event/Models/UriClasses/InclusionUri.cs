﻿namespace Event.Models.UriClasses
{
    public class InclusionUri : UriRepresentationBase
    {
    }
}