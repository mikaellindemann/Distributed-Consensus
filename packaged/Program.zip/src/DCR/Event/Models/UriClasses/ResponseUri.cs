﻿namespace Event.Models.UriClasses
{
    public class ResponseUri : UriRepresentationBase
    {
    }
}