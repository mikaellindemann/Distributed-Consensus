﻿namespace Event.Models.UriClasses
{
    public class MilestoneUri : UriRepresentationBase
    {
    }
}