﻿DELETE FROM ServerWorkflowModels;
DELETE FROM EventRoles;
DELETE FROM HistoryModels;
DELETE FROM ServerEventModels;
DELETE FROM ServerRoleModels;
DELETE FROM ServerUserModels;
DELETE FROM UserRoles;

DELETE FROM ServerWorkflowModels;
DELETE FROM EventRoles;
DELETE FROM HistoryModels;
DELETE FROM ServerEventModels;
DELETE FROM ServerRoleModels;
DELETE FROM ServerUserModels;
DELETE FROM UserRoles;