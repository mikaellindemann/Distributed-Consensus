﻿using System;

namespace Event.Exceptions.ServerInteraction
{
    public class FailedToDeleteEventFromServerException : Exception
    {
    }
}