﻿using System;

namespace Event.Exceptions.ServerInteraction
{
    public class FailedToPostEventAtServerException : Exception
    {
    }
}