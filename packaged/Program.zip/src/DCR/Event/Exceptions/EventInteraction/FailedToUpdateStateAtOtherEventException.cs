using System;

namespace Event.Exceptions.EventInteraction
{
    public class FailedToUpdateStateAtOtherEventException : Exception
    {
    }
}