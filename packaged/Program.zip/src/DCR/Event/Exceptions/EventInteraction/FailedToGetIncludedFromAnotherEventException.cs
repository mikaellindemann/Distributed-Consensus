﻿using System;

namespace Event.Exceptions.EventInteraction
{
    public class FailedToGetIncludedFromAnotherEventException : Exception
    {
    }
}