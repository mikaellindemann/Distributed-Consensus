﻿using System;

namespace Event.Exceptions.EventInteraction
{
    public class FailedToUpdateExcludedAtAnotherEventException : Exception
    {
    }
}