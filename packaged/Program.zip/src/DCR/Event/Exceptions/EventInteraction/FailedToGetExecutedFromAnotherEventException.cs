﻿using System;

namespace Event.Exceptions.EventInteraction
{
    public class FailedToGetExecutedFromAnotherEventException : Exception
    {
    }
}