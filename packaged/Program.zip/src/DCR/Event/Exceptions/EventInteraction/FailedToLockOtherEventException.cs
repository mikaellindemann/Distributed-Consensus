using System;

namespace Event.Exceptions.EventInteraction
{
    public class FailedToLockOtherEventException : Exception
    {
    }
}