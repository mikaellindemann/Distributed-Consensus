﻿using System;

namespace Common.Exceptions
{
    public class LockedException : Exception
    {
    }
}