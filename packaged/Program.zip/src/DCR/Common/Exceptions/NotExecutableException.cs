﻿using System;

namespace Common.Exceptions
{
    public class NotExecutableException : Exception
    {
    }
}