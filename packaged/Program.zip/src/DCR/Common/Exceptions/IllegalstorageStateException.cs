﻿using System;

namespace Common.Exceptions
{
    public class IllegalStorageStateException : Exception
    {
    }
}