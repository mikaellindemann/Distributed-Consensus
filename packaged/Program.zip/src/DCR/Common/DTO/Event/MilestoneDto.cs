namespace Common.DTO.Event
{
    public class MilestoneDto
    {
        public bool Milestone { get; set; }
        public int TimeStamp { get; set; }
    }
}