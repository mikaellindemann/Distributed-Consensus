namespace Common.DTO.Event
{
    public class ConditionDto
    {
        public bool Condition { get; set; }
        public int TimeStamp { get; set; }
    }
}