﻿using System;

namespace Server.Exceptions
{
    public class UserExistsException : Exception
    {
    }
}