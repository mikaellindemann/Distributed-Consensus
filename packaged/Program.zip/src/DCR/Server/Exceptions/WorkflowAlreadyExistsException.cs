using System;

namespace Server.Exceptions
{
    public class WorkflowAlreadyExistsException : Exception
    {
    }
}