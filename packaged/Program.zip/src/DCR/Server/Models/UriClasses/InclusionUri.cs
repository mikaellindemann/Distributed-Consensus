﻿namespace Server.Models.UriClasses
{
    public class InclusionUri : UriRepresentationBase
    {
    }
}