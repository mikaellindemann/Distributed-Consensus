﻿namespace Server.Models.UriClasses
{
    public class MilestoneUri : UriRepresentationBase
    {
    }
}