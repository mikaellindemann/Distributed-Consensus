﻿namespace Server.Models.UriClasses
{
    public class ExclusionUri : UriRepresentationBase
    {
    }
}