﻿namespace Server.Models.UriClasses
{
    public class ResponseUri : UriRepresentationBase
    {
    }
}