﻿namespace Server.Models.UriClasses
{
    public class ConditionUri : UriRepresentationBase
    {
    }
}